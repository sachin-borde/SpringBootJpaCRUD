package com.csi.SpringBootJpaEmployee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
